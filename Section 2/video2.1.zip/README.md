# ansible

## Ansible Installation on REHL6/FEDORA7/Centos
## Ansible Installation on Ubuntu
## Ansible User setup
## Ansible Controller 
